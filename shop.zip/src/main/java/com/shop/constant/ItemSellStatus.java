package com.shop.constant;

// enum = 여기 외 다른값을 넣지 마라
public enum ItemSellStatus {
    SELL, SOLD_OUT
}
